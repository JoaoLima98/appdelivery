export type StoresProps = {
    id: string;
    name: string;
    image:string;
    rate:string;
}