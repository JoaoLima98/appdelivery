import BannerPromotion from "@/assets/images/banner1.png";
import BannerPromotion2 from "@/assets/images/banner2.png";

export const Banners = [{id:1, image: BannerPromotion}, {id: 2,image: BannerPromotion2}]