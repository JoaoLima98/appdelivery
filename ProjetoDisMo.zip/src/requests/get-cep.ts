const getCep = async (cep: string) => {
    return cep
}